module.exports = {
	config: {
		name: "war",
		version: "1.0",
		author: "Xemon",
		role: 2,
		category: "texts",
		guide: {
			vi: "Not Available",
			en: "cpx @(mention)"
		} 
	},

  onStart: async function ({ api, event, userData, args }) {
      var mention = Object.keys(event.mentions)[0];
    if(!mention) return api.sendMessage("Need to tag 1 friend whome you want to scold with bad words", event.threadID);
 let name =  event.mentions[mention];
    var arraytag = []; 
        arraytag.push({id: mention, tag: name});
    var a = function (a) { api.sendMessage(a, event.threadID); }
setTimeout(() => {a({body: "RANDIKO CHOKTAA MUJII RAUTEE KHATE KO XORO AMA CHIKWAA MUJI " + " " + name, mentions: arraytag})}, 3000);
setTimeout(() => {a({body: "LADOOO LES TAT TC TAUKEE SALLAA XKKKAAA TEORO PUTI MA MERO NAM LEKHXU ABAA😭💋" + " " + name, mentions: arraytag})}, 5000);
setTimeout(() => {a({body: "TEORO AMA KO PUTI MA DAHI HALERW LYAAMM LYAM CHIKAMAMMM BHNNTW🤠❤" + " " + name, mentions: arraytag})}, 7000);
setTimeout(() => {a({body: "TERII AMA KO KALO PUTII MA LYAMMMA LYAMMA CHKAMM MUJII THUKK LAII LAII MADRCHOOOD BESYYA AMA KO XORO" + " " + name, mentions: arraytag})}, 9000);
setTimeout(() => {a({body: "TEORO AMAA LAAII KOPCHI MAA LAGERW CHIKAAMM RANNDDII MAKAA BAXHHA😭💋" + " " + name, mentions: arraytag})}, 12000);
setTimeout(() => {a({body: "TERO AAMA LAAII MERO LADO MAA BASAII NEPAALL GHUMAUXXUU RANNDDI MAA KAA BXHHAA😭" + " " + name, mentions: arraytag})}, 14000);
setTimeout(() => {a({body: "TEERII MAA KI CHUTT PAKAR K RODDD DALDUU BEHENCHODDD SALA NALAYKK BACHHA ANPADDD MUJIII" + " " + name, mentions: arraytag})}, 16000);
setTimeout(() => {a({body: "TEROO AMAA KO KALO PUTII MA SARAF HAALI GORO BANA JAA XORO 🤠❤" + " " + name, mentions: arraytag})}, 18000);
setTimeout(() => {a({body: "TRII BEHN KI KALII CHUTT UMMAHH MADRCHOOOD EXYY  PJUTII TERIII BAINIKO RATOO RATOO CHIKI CHIKI LYAMMA LYMMA" + " " + name, mentions: arraytag})}, 20000);
setTimeout(() => {a({body: "TEOROO AMAA KO PUTTII MAA COKEE HAALII BDAYY PARTY MANAAMAM MEROOLADO KO😭💋" + " " + name, mentions: arraytag})}, 22000);
setTimeout(() => {a({body: "MEROO LADOO DHOGNNAA AIJAA SALALA XKK KO BXHHHA RNNDII KO BAXHHAA😭💋" + " " + name, mentions: arraytag})}, 2400);
setTimeout(() => {a({body: "TERII BAHINILAII MEROO LADOO MA JHUNDAYE MARDENXUU SALA DAMAII KO BACHHA HAKKK THUUU HAHAHAHAHA" + " " + name, mentions: arraytag})}, 26000);
setTimeout(() => {a({body: "HAKKK THUUU MUJIIII VAGGG SALA ABAUU ANGAA BOLNEE AUKAAT BANA PAHELE ANI AIJNAAA ALA RAUTE KO BACHHHA KHIKHIHKHI" + " " + name, mentions: arraytag})}, 28000);
setTimeout(() => {a({body: "MEROO LAODO LE HAANI TEORO KHAANNDANN DAFANN HAANNDDIMM FUCHEHEEE😭💋" + " " + name, mentions: arraytag})}, 30000);
setTimeout(() => {a({body: "MEROO LADOO KO JHATTAROO HANEE TERIII AMA KO TAUKOO FUTALXUU RANDIKO BANN HAHHAHA " + " " + name, mentions: arraytag})}, 32000);
setTimeout(() => {a({body: "TEROO NIDHARR MAA MEROOLAODO KO JHATAROO HAANI CHAAPP BASAUXUU😭💋" + " " + name, mentions: arraytag})}, 65000);
setTimeout(() => {a({body: "LADOOOMA KISS HANN FUVCHHHEE RANDIKO XORO " + " " + name, mentions: arraytag})}, 34000);
setTimeout(() => {a({body: "TERROO AMA KO PUTI MA LAGAII TORI KO TELL CHIKI CHIKI GRDINXXUU PUTI TROO AMA KO FAILLL🤠❤" + " " + name, mentions: arraytag})}, 36000);
setTimeout(() => {a({body: "RANDIKKO BACHHHA SALA UMMMAHH MADRCHOOD TERII AMAMO RATOO PJUTII MAAA ALA PUTII HOWW HANN VANTAA  OA TERII AMA LAII MERO NAM LEYERW" + " " + name, mentions: arraytag})}, 38000);
setTimeout(() => {a({body: "TROO AMAA KO PUTI YETI ADHYARO KALO XA KI CHIKDA TERO AMA LAI TORCH BALI BALI HERNA PARX🤠❤" + " " + name, mentions: arraytag})}, 40000);
setTimeout(() => {a({body: "TEROO KHAANNDAAN LAAII MEROO LADO LE HANERW DHALLDIMM XAKKEE MC FUCHEY🤠❤" + " " + name, mentions: arraytag})}, 44000);
setTimeout(() => {a({body: "BAUU VANN RANDIKOO CHOKTAA MUJII DALITTE SALAA  HAHAHAHAHA " + " " + name, mentions: arraytag})}, 460000);
setTimeout(() => {a({body: "TEROO AMAA LAAI RATI BED MA LAGII VTENN KO SONGG MA NACHDAI UFRII DAI LYAAMM LYAMMM CHIKAAMM RDD KOO NSOO🤠🫀" + " " + name, mentions: arraytag})}, 48000);
setTimeout(() => {a({body: "OLELEL MUJI NA RONARONA RANDIKO BAN VALU TERI AMA RAMDIKO XORO" + " " + name, mentions: arraytag})} , 50000);
setTimeout(() => {a({body: "LADOLEES XORO MUJI TERI AMA CHIKI CHIKI CONDOM FUTERWWW JANMYAKO TALAII ASLAAA" + " " + name, mentions: arraytag})} , 52000);
setTimeout(() => {a({body: "TERII AMA KO KALO PUTII MA UMMAH" + " " + name, mentions: arraytag})} , 56000);
setTimeout(() => {a({body: "THOPPDAA PDDIIT SLALA  XORORO TEORO THOPPDA HERDAA MEROO UTHEEKO LADOO NI SUTXA🙀❤" + " " + name, mentions: arraytag})} , 58000);
setTimeout(() => {a({body: "TWROO AMAA NAII HO MEROO TURUU AND PURE LOVE KANNXXOO😘😘" + " " + name, mentions: arraytag})} , 60000);
setTimeout(() => {a({body: "TEROO BAAINI LAI GULAABI PUTII SHOW GARNAA VANTA BAAU KO AGHADDII😻" + " " + name, mentions: arraytag})} , 62000);
setTimeout(() => {a({body: "TEOROO AAMA NEPAALL TOP RANNDI HAINAA UNIVERSALL TOP RANDI KO KANXXOO🤠❤"+ " " + name, mentions: arraytag})} , 64000);
setTimeout(() => {a({body: "TEROOO BAAINI RW TEORO AMAA LAAII MERAII SINGLE BED MA DUITAI LAII EUTAI THAU MA SUTAI SANGAII CHIKXU 🤠❤" + " " + name, mentions: arraytag})} , 66000);
setTimeout(() => {a({body: "TEROO AMAA LEEE MEROO LADO KO YAADD MA SADHAI RATI 1 BAJE FINGERINGG GARXA🤠❤" + " " + name, mentions: arraytag})} , 68000);
setTimeout(() => {a({body: "RANNDI KO BACHAHHA SLALAA AMA KO KALO CHAURII PAREKO PUTII JASTAI THOPDA BOKER BAU KO AGHADI AUUXAS🤣🤣🤣" + " " + name, mentions: arraytag})} , 70000);
setTimeout(() => {a({body: "TROOO AMA LIAI CHIKER MAILE DEKO PAAISA LE TEROO GHAR CHHALXA XOROO SLA VIKARIIII🤠❤" + " " + name, mentions: arraytag})} , 72000);
setTimeout(() => {a({body: "TEOROO AMA KO KAANNDDOO MADALL JHAAII BAJAAMM BHAANNT SLA XORO🤠♥" + " " + name, mentions: arraytag})} , 74000);
setTimeout(() => {a({body: "TEROO AMAA KO BESYA PUTII SHOWW HAAN TW SLAA XOROO🤠❤" + " " + name, mentions: arraytag})} , 76000);
setTimeout(() => {a({body: "TEROOO AMA KO SABLEE PUTII CHIKER DULO NI YETROO BHAXA SLAAA TEORO PURA KHAANNDAN KOCHAREY NI AJHA DHERAI THAU BAKI RAHAANNXA🤠❤" + " " + name, mentions: arraytag})} , 78000);
setTimeout(() => {a({body: "TEROO AMAA KO KAALO PUTII PUTII HAINAA BLACKK HOLEE HO MCC JATI OTA LADO NI ATNEE🤠❤" + " " + name, mentions: arraytag})} , 80000);
setTimeout(() => {a({body: "PAILAA LEVEL MILA ANII AAIJAA JATHOO MADARCHOOD" + " " + name, mentions: arraytag})} , 82000);
setTimeout(() => {a({body: "LWW MACHIKNEYY RANDIKOO NASOO MA GAYE ABA TA JATHOO SAKDAINAS MA SANGAA FYTT HANNA" + " " + name, mentions: arraytag})} , 84000);
setTimeout(() => {a({body: "XEMON THE GREAT EXIT!!😾🥀🤣" + " " + name, mentions: arraytag})} , 84000);
  }
};